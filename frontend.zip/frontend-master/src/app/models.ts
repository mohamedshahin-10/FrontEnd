export type User = {
  name: string;
  email: string;
  password: string;
  occupation: string;
  careerLevel: string;

}
export type Result = {

}
